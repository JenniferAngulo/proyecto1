/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainapp;

/**
 *
 * @author sthephano
 */
public class Tecnico extends Usuario{
    private String contraseña;

    public Tecnico(String contraseña, String nombre, String apellido, String dni, String telf, String direccion) {
        super(nombre, apellido, dni, telf, direccion);
        this.contraseña = contraseña;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
    
    
    
    
    
    
}
