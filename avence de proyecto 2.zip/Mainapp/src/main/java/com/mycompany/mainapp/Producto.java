/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainapp;

/**
 *
 * @author sthephano
 */
public class Producto extends Cliente {
    private String modelo;
    private String serie;

    public Producto(String modelo, String serie, String nombre, String apellido, String dni, String telf, String direccion) {
        super(nombre, apellido, dni, telf, direccion);
        this.modelo = modelo;
        this.serie = serie;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }
    
    
   
    
    
    
}
